/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modeles;

import java.util.Date;

/**
 *
 * @author ibrahimabenmadykebe
 */
public abstract class Personne {
    protected static int cpt;
    protected int id;
    protected String nom;
    protected String prenom;
    protected Date dateNaiss;
    protected String numero;

    public Personne(int id) {
        this.id = id;
    }

    public static int getCpt() {
        return cpt;
    }

    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public Date getDateNaiss() {
        return dateNaiss;
    }

    public String getNumero() {
        return numero;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String Prenom) {
        this.prenom = Prenom;
    }

    public void setDateNaiss(Date dateNaiss) {
        this.dateNaiss = dateNaiss;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    @Override
    public String toString() {
        return  "Personne{" + "id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", dateNaiss=" + dateNaiss + ", numero=" + numero + '}';
//To change body of generated methods, choose Tools | Templates.
    }


    
    
    
    
  
}
