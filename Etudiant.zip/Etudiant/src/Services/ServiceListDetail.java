/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Services;

import java.util.ArrayList;
import Modeles.Classe;
import Modeles.Etudianttt;
import Modeles.Professeur;
/**
 *
 * @author ibrahimabenmadykebe
 */
public class ServiceListDetail {
  public static final ArrayList <Professeur> ListeProfesseur = new ArrayList<Professeur>();
  
  public boolean creerPersonne(Professeur p){
      ListeProfesseur.add(p);
              return true;
  }
    
  public ArrayList<Professeur> ListeProf(){
      return ListeProfesseur;
  }
  
   public static final ArrayList <Etudianttt> ListeEtudianttt= new ArrayList<Etudianttt>();
  
  public boolean creerPersonne(Etudianttt p){
      ListeEtudianttt.add(p);
              return true;
  }
    
  public ArrayList<Etudianttt> ListeEtudiant(){
      return ListeEtudianttt;
  }
  
   public static final ArrayList<Classe> ListeClasse= new ArrayList<Classe>();
  
  public boolean creerClasse(Classe p){
      ListeClasse.add(p);
              return true;
  }
    
  public ArrayList<Classe> ListeClasse(){
      return ListeClasse;
}
  
}
