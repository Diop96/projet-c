﻿namespace GestionCom
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFrmUserGo = new System.Windows.Forms.Button();
            this.btnFrmProfilGo = new System.Windows.Forms.Button();
            this.btnFrmCommandeGo = new System.Windows.Forms.Button();
            this.btnFrmCategorieGo = new System.Windows.Forms.Button();
            this.btnFrmArticleGo = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(939, 62);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.label2.Location = new System.Drawing.Point(734, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Profil";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GestionCom.Properties.Resources.ExecutiveCar_Black_icon_icons_com_54904;
            this.pictureBox1.Location = new System.Drawing.Point(12, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label1.Location = new System.Drawing.Point(181, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Bienvenue,";
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 59);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(147, 393);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.btnFrmUserGo);
            this.panel3.Controls.Add(this.btnFrmProfilGo);
            this.panel3.Controls.Add(this.btnFrmCommandeGo);
            this.panel3.Controls.Add(this.btnFrmCategorieGo);
            this.panel3.Controls.Add(this.btnFrmArticleGo);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 62);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(160, 476);
            this.panel3.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(8, 235);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 20);
            this.label8.TabIndex = 10;
            this.label8.Text = "Commande";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(12, 310);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "Profil";
            // 
            // btnFrmUserGo
            // 
            this.btnFrmUserGo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmUserGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrmUserGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrmUserGo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFrmUserGo.Location = new System.Drawing.Point(42, 371);
            this.btnFrmUserGo.Name = "btnFrmUserGo";
            this.btnFrmUserGo.Size = new System.Drawing.Size(94, 37);
            this.btnFrmUserGo.TabIndex = 8;
            this.btnFrmUserGo.Text = "Utilisateur";
            this.btnFrmUserGo.UseVisualStyleBackColor = true;
            this.btnFrmUserGo.Click += new System.EventHandler(this.btnFrmUserGo_Click);
            // 
            // btnFrmProfilGo
            // 
            this.btnFrmProfilGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmProfilGo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmProfilGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrmProfilGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrmProfilGo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFrmProfilGo.Location = new System.Drawing.Point(31, 333);
            this.btnFrmProfilGo.Name = "btnFrmProfilGo";
            this.btnFrmProfilGo.Size = new System.Drawing.Size(88, 32);
            this.btnFrmProfilGo.TabIndex = 7;
            this.btnFrmProfilGo.Text = "Profil";
            this.btnFrmProfilGo.UseVisualStyleBackColor = false;
            this.btnFrmProfilGo.Click += new System.EventHandler(this.btnFrmProfilGo_Click);
            // 
            // btnFrmCommandeGo
            // 
            this.btnFrmCommandeGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmCommandeGo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmCommandeGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrmCommandeGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrmCommandeGo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFrmCommandeGo.Location = new System.Drawing.Point(50, 258);
            this.btnFrmCommandeGo.Name = "btnFrmCommandeGo";
            this.btnFrmCommandeGo.Size = new System.Drawing.Size(88, 35);
            this.btnFrmCommandeGo.TabIndex = 6;
            this.btnFrmCommandeGo.Text = "Ajouter";
            this.btnFrmCommandeGo.UseVisualStyleBackColor = false;
            this.btnFrmCommandeGo.Click += new System.EventHandler(this.btnFrmCommandeGo_Click);
            // 
            // btnFrmCategorieGo
            // 
            this.btnFrmCategorieGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmCategorieGo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmCategorieGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrmCategorieGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrmCategorieGo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFrmCategorieGo.Location = new System.Drawing.Point(56, 202);
            this.btnFrmCategorieGo.Name = "btnFrmCategorieGo";
            this.btnFrmCategorieGo.Size = new System.Drawing.Size(88, 30);
            this.btnFrmCategorieGo.TabIndex = 5;
            this.btnFrmCategorieGo.Text = "Categorie";
            this.btnFrmCategorieGo.UseVisualStyleBackColor = false;
            this.btnFrmCategorieGo.Click += new System.EventHandler(this.btnFrmCategorieGo_Click);
            // 
            // btnFrmArticleGo
            // 
            this.btnFrmArticleGo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmArticleGo.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(50)))), ((int)(((byte)(68)))));
            this.btnFrmArticleGo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFrmArticleGo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFrmArticleGo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnFrmArticleGo.Location = new System.Drawing.Point(48, 168);
            this.btnFrmArticleGo.Name = "btnFrmArticleGo";
            this.btnFrmArticleGo.Size = new System.Drawing.Size(88, 28);
            this.btnFrmArticleGo.TabIndex = 4;
            this.btnFrmArticleGo.Text = "Article";
            this.btnFrmArticleGo.UseVisualStyleBackColor = false;
            this.btnFrmArticleGo.Click += new System.EventHandler(this.btnFrmArticleGo_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label6.Location = new System.Drawing.Point(8, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Stock";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label5.Location = new System.Drawing.Point(19, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 24);
            this.label5.TabIndex = 2;
            this.label5.Text = "Dashbord";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Location = new System.Drawing.Point(52, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Commercial";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label3.Location = new System.Drawing.Point(3, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Gestion ";
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(939, 538);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.IsMdiContainer = true;
            this.Name = "FrmMenu";
            this.Text = "FrmMenu";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFrmUserGo;
        private System.Windows.Forms.Button btnFrmProfilGo;
        private System.Windows.Forms.Button btnFrmCommandeGo;
        private System.Windows.Forms.Button btnFrmCategorieGo;
        private System.Windows.Forms.Button btnFrmArticleGo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}